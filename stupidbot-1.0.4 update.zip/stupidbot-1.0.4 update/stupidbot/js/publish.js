$(function(){
	chrome.storage.local.get({posts: []}, async function(result){
    await sleep(150);
    console.log(result);
    if(result.posts.length > 0){
      show('form');
      hide('loading');
      set('title', 'Please select publishing platform');
      set('status',  result.posts.length + ' posts will be published');
    }
    else{
      hide('form');
      hide('loading');
      set('title', 'No post found, please create first');
      show('create_btn');
    }
  });
});