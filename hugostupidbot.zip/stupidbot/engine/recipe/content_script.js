function getPageUrls() {
    var recipeCount = getRecipeCount();
    var maxPage = Math.ceil(recipeCount / 20);
    if (recipeCount > 240) {
        maxPage = 12;
    }

    var pageURLs = [];

    for (var i = 1; i <= maxPage; i++) {
        pageURLs[i - 1] = window.location.href.split("?")[0] + "?page=" + i;
    }

    return pageURLs;
}

function baseURL() {
    return "https://cookpad.com";
}

function getRecipeCount() {
    return $("h1.flex-1 span").text().replace(/[^0-9,]+/g,'');
}

function getRecipeUrls() {
    var recipe_urls = [];
    $("ul li.flex a").each(function (index) {
        recipe_urls.push(baseURL() + $(this).attr("href"));
    });

    return $.unique(recipe_urls);
}

function getTitleTag() {
    return $("title").text();
}

function isBlocked() {
    var block_words = ["denied", "refus"];

    for (var i = block_words.length - 1; i >= 0; i--) {
        if (getTitleTag().includes(block_words[i])) {
            return true;
        }
    }

    return false;
}

function getRecipe() {
    var recipe = {};

    // title
    recipe.title = $("h1").first().text().trim();
    recipe.image = $("#recipe_image img").attr("src");

    // todo: description

    // author
    recipe.author = $("span[itemprop=author] span[itemprop=name]").text();
    recipe.time = $(".icf--timer").parent().text().trim();

    if (recipe.time.includes("\n")) {
        recipe.time = recipe.time.substr(0, recipe.time.indexOf("\n"));
    }

    recipe.servings = $(".icf--user").parent().text().trim();

    // author location
    recipe.author_location = $("#location").text();

    recipe.author_avatar = $(".author-container img").attr("src");

    recipe.author_description = $("#author_profile .py-2").text().trim();

    recipe.ingredients = [];

    $("li.leading-tight").each(function (i) {
        var ingredient = {};
        ingredient.quantity = $(this)
            .find(".font-semibold")
            .text()
            .trim();
        $(this).find(".font-semibold").remove();
        ingredient.name = $(this)
            .find("div[itemprop=ingredients]")
            .text()
            .trim();

        recipe.ingredients.push(ingredient);
    });

    recipe.steps = [];

    $("li.step").each(function (i) {
        var step = {};
        step.instruction = $(this).text().trim();
        step.images = [];

        $(this)
            .find("img")
            .each(function () {
                var image = $(this).attr("src");
                if (image && image.trim().length) {
                    step.images.push(image);
                }
            });

        recipe.steps.push(step);
    });

    recipe.related_keywords = [];

    $(".btn-search-term").each(function (i) {
        recipe.related_keywords.push($(this).text().trim());
    });

    return recipe;
}
