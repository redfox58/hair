$(function(){
	$('#start').click(function(e){
		e.preventDefault();
		var data = $('form').serializeJSON();
		
		$('#resume_btn').addClass('d-none');
	    $('#spinner').removeClass('d-none');
	    toggle('Scraping in progress...');
		
		chrome.runtime.sendMessage({command: 'scrape', data: data});
	});
});