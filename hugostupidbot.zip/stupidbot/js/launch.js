$(function(){
	engine(function(engine){
		var url = '/engine/' + engine + '/scrape.html';
		console.log(url);
    window.location = url;
	});
});