var zip = new JSZip();

$(function(){
	$('#publish').click(function(){

		var data = {};
		data.name = $('#name').val();
		data.description = $('#description').val();
		data.pages = ['index', 'contact', 'copyright', 'dmca', 'privacy-policy'];
		data.nice_pages = ['Index', 'Contact', 'Copyright', 'DMCA', 'Privacy-Policy'];

		show('loading');
		setHeading('Starting up...');
		hide('form');
		chrome.storage.local.get({posts: []}, function(result){

			data.divided_posts = result.posts.divideInto(3);
			data.posts = result.posts;
			data._ = _;
			data.chance = chance;
			data.post = {};

			$.get('/templates/html/layout.html', function(layout){
				generatePages(layout, data);
			});
		});
	});
});

function generatePages(layout, data){
	page = data.pages.shift();

	renderHtml(layout, page, data, function(output){
		zip.file(page+'.html', output);

		if(data.pages.length == 0){
			// start generate posts
			generatePosts(layout, data);
		}
		else{
			generatePages(layout, data);
		}
	});
}


function generatePosts(layout, data){
	var post = data.posts.shift();
	data.content = post.content;
	data.name = post.title;
	data.post = post;
	setHeading('Creating ' + post.title + '...');

	var output = ejs.render(layout, data);

	zip.file(post.slug + '.html', output);

	if(data.posts.length == 0){
		setHeading('Your download will begin...');
		downloadZip();
	}
	else{
		generatePosts(layout, data);
	}
}



function downloadZip(){
	zip.generateAsync({type:"blob"})
	.then(function(content) {
	    // see FileSaver.js
	    saveAs(content, "html.zip");
	});
}

function renderHtml(layout, template, data, callback){
	$.get('/templates/html/'+ template +'.html', function(page){
		setHeading('Creating '+ template +'...');
		var content = ejs.render(page, data);
		data.content = content;

		var output = ejs.render(layout, data);
		callback(output);
	});	
}