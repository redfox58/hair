$(function(){
	$('#download_wxr').click(function(){
		show('loading');
		setHeading('Downloading...');
		chrome.storage.local.get({posts: []}, function(result){
			$.get('templates/wp.html', function(wp){
				var wxr = ejs.render(wp, {posts: result.posts});

				var blob = new Blob([wxr], {type: "application/xml"});
			    var url = URL.createObjectURL(blob);
			    chrome.downloads.download({
			      url: url,
			      filename: 'wp-' + (new Date()).getTime() + '.wxr'
			    });
			});
		});
	});
});