
{
  "title": "Coto makassar ",
  "image": "https://img-global.cpcdn.com/recipes/6654474426ab56ab/680x482cq70/coto-makassar-recipe-main-photo.jpg",
  "LanguageCode": "",
  "future": True
  "PublishDate: "2021-04-15T17:43:20.058Z",
  "thumbnail": "https://img-global.cpcdn.com/recipes/6654474426ab56ab/680x482cq70/coto-makassar-recipe-main-photo.jpg",
  "cover": "https://img-global.cpcdn.com/recipes/6654474426ab56ab/680x482cq70/coto-makassar-recipe-main-photo.jpg",
  "categories": "Uncategorized",
  "recipecategory": "Uncategorized"
  "keywords": "Uncategorized",
  "nutrition": "227 calories",
  "tag": ["indonesia", "launch"],
  "recipeyield": "1"
  "description": "cara mudah membuat Coto makassar"
  "author": "Beatrice Mann",
  "preptime": "PT34M",
  "cooktime": "PT1H",
  "calories": "156 calories",
  "fatContent": "6 grams fat",
  "ratingValue": "4.3",
  "reviewCount": "6", 
  "recipeIngredient": [
		"100 gm rice", 
		"500 ml water", 
		"pinch salt", 
		"pinch sugar", 
		"250 gm beef mince", 
		"100 gm cooked oxtail meat shredded", 
		"1 tbsp white pepper", 
		"1 pinch nutmeg", 
		"1 tbsp coriander seeds roasted  ground", 
		"2 egg whites separated", 
		"50 ml vegetable oil", 
		"4 tbsp galangal dried", 
		"4 tbsp lemongrass dried", 
		"1 tbsp crushed garlic", 
		"40 ml coconut milk", 
		"1 L beef stock", 
		" garnish", 
		" lime slices or wedges", 
		" fried shallots", 
		"1 long red chilli finely sliced", 
		" spring onions sliced"
		],
  "recipeInstructions": [ 
        "Soak the rice in water with a pinch of salt and sugar for 30 minutes and drain reserving the starchy water", 
        "To make the meatballs add the mince meat and cooked oxtail in a bowl and season with salt to taste and the white pepper Mix with nutmeg 2 teaspoons of the ground coriander seeds and egg whites Roll tablespoons of the mixture into balls and set aside", 
        "Heat the vegetable oil in a large wok and add the galangal lemongrass garlic and the remainder of the ground coriander Saut stirring for about 2 minutes or until aromatic Mix the egg yolk with the coconut milk and add to the pan with the starchy rice water Stir and add beef stock Bring to the boil and simmer for about 45 minutes", 
        "Meanwhile sear the meatballs in another deep frypan over high heat Once theyre evenly browned add the beef stock mixture over the top of the meatballs Simmer until the meatballs are cooked through and serve garnished with shallots lime wedges spring onions and red chilliesNOTESSoaking time 30 minutes"]
}






![Coto makassar](https://img-global.cpcdn.com/recipes/6654474426ab56ab/680x482cq70/coto-makassar-recipe-main-photo.jpg)
Ibu sedang mencari ide resep coto makassar yang unik? 

Berikut ini ada beberapa cara mudah dan praktis dalam mengolah coto makassar yang siap dikreasikan. Nah, kali ini kita coba, yuk, kreasikan coto makassar sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh sekeluarga. Anda dapat menyiapkan Coto makassar memakai 21 jenis bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.
<!--inarticleads1-->
#### Bahan-bahan Yang diperlukan untuk menyiapkan Coto makassar:

- Sediakan **100 gm** rice. 
- Sediakan **500 ml** water. 
- Sediakan **pinch** salt. 
- Sediakan **pinch** sugar. 
- Sediakan **250 gm** beef mince. 
- Siapkan **100 gm** cooked oxtail meat, shredded. 
- Sediakan **1 tbsp** white pepper. 
- Persiapkan **1 pinch** nutmeg. 
- Sediakan **1 tbsp** coriander seeds, roasted &amp; ground. 
- Persiapkan **2** egg, whites separated. 
- Sediakan **50 ml** vegetable oil. 
- Siapkan **4 tbsp** galangal (dried). 
- Persiapkan **4 tbsp** lemongrass (dried). 
- Sediakan **1 tbsp** crushed garlic. 
- Persiapkan **40 ml** coconut milk. 
- Siapkan **1 L** beef stock. 
- Persiapkan **** garnish. 
- Siapkan **** lime slices or wedges. 
- Sediakan **** fried shallots. 
- Siapkan **1** long red chilli, finely sliced. 
- Sediakan **** spring onions, sliced. 
<!--inarticleads2-->	
#### Cara Mengolah Coto makassar:
		
1. Soak the rice in water with a pinch of salt and sugar for 30 minutes and drain, reserving the starchy water.		
1. To make the meatballs, add the mince meat and cooked oxtail in a bowl and season with salt, to taste, and the white pepper. Mix with nutmeg, 2 teaspoons of the ground coriander seeds and egg whites. Roll tablespoons of the mixture into balls and set aside.		
1. Heat the vegetable oil in a large wok and add the galangal, lemongrass, garlic and the remainder of the ground coriander. Sauté, stirring, for about 2 minutes or until aromatic. Mix the egg yolk with the coconut milk and add to the pan with the starchy rice water. Stir, and add beef stock. Bring to the boil, and simmer for about 4-5 minutes.		
1. Meanwhile, sear the meatballs in another deep frypan over high heat. Once they’re evenly browned, add the beef stock mixture over the top of the meatballs. Simmer until the meatballs are cooked through, and serve garnished with shallots, lime wedges, spring onions, and red chillies.

NOTES

Soaking time: 30 minutes.
<!--inarticleads3-->	

    