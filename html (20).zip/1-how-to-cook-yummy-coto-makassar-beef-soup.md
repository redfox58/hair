
{
  "title": "Coto Makassar  Beef Soup ",
  "image": "https://img-global.cpcdn.com/recipes/1a52f5f641e2bc48/680x482cq70/coto-makassar-beef-soup-recipe-main-photo.jpg",
  "LanguageCode": "",
  "future": True
  "PublishDate: "2021-03-28T14:34:46.737Z",
  "thumbnail": "https://img-global.cpcdn.com/recipes/1a52f5f641e2bc48/680x482cq70/coto-makassar-beef-soup-recipe-main-photo.jpg",
  "cover": "https://img-global.cpcdn.com/recipes/1a52f5f641e2bc48/680x482cq70/coto-makassar-beef-soup-recipe-main-photo.jpg",
  "categories": "Uncategorized",
  "recipecategory": "Uncategorized"
  "keywords": "Uncategorized",
  "nutrition": "208 calories",
  "tag": ["indonesia", "launch"],
  "recipeyield": "2"
  "description": "cara mudah membuat Coto Makassar / Beef Soup"
  "author": "Birdie Moreno",
  "preptime": "PT30M",
  "cooktime": "PT1H",
  "calories": "207 calories",
  "fatContent": "9 grams fat",
  "ratingValue": "4.3",
  "reviewCount": "10", 
  "recipeIngredient": [
		"500 g beef", 
		"500 g beef tripe", 
		"2 stalks lemon grass take only the white part bruised", 
		"2 inch galangal bruised", 
		"1 tbsp. salt", 
		"1 tsp palm sugar", 
		"2 L water", 
		"100 g peanut roasted and ground coarsely", 
		"5 tbsp. cooking oil", 
		" Blend into paste", 
		"10 cloves garlic", 
		"5 shallots", 
		"4 red chillies", 
		"4 Thai chillies", 
		"4 pcs candlenuts", 
		"2 tbsp. tauco fermented soy beans", 
		"4 tbsp. coriander powder", 
		"1 tbsp. black pepper powder"
		],
  "recipeInstructions": [ 
        "In a soup pot heat cooking oil and fry spice paste until fragrant about 5 minutes Add in lemon grass galangal beef beef tripe salt sugar peanut and water bring to boil Reduce heat and simmer for about 30 minutes", 
        "Remove the beef and beef tripe cut into small pieces Return to the pot and bring to another boil simmer for another 1 hour until tender", 
        ""]
}






![Coto Makassar / Beef Soup](https://img-global.cpcdn.com/recipes/1a52f5f641e2bc48/680x482cq70/coto-makassar-beef-soup-recipe-main-photo.jpg)
Sedang mencari ide resep coto makassar / beef soup yang unik? 

Berikut ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah coto makassar / beef soup yang siap dikreasikan. Nah, kali ini kita coba, yuk, buat coto makassar / beef soup sendiri di rumah. Tetap berbahan sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuh sekeluarga. Anda dapat menyiapkan Coto Makassar / Beef Soup menggunakan 18 bahan dan 3 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.
<!--inarticleads1-->
#### Beberapa Bahan Yang digunakan untuk pembuatan Coto Makassar / Beef Soup:

- Siapkan **500 g** beef. 
- Persiapkan **500 g** beef tripe. 
- Persiapkan **2 stalks** lemon grass, take only the white part, bruised. 
- Siapkan **2 inch** galangal, bruised. 
- Sediakan **1 tbsp.** salt. 
- Persiapkan **1 tsp** palm sugar. 
- Persiapkan **2 L** water. 
- Sediakan **100 g** peanut, roasted and ground coarsely. 
- Siapkan **5 tbsp.** cooking oil. 
- Persiapkan **** Blend into paste:. 
- Siapkan **10 cloves** garlic. 
- Persiapkan **5** shallots. 
- Sediakan **4** red chillies. 
- Persiapkan **4** Thai chillies. 
- Siapkan **4 pcs** candlenuts. 
- Sediakan **2 tbsp.** tauco (fermented soy beans). 
- Persiapkan **4 tbsp.** coriander powder. 
- Sediakan **1 tbsp.** black pepper powder. 
<!--inarticleads2-->	
#### Langkah-langkah Mengolah Coto Makassar / Beef Soup:
		
1. In a soup pot, heat cooking oil and fry spice paste until fragrant, about 5 minutes. Add in lemon grass, galangal, beef, beef tripe, salt, sugar, peanut and water, bring to boil. Reduce heat and simmer for about 30 minutes.		
1. Remove the beef and beef tripe, cut into small pieces. Return to the pot and bring to another boil, simmer for another 1 hour until tender.		
1. 
<!--inarticleads3-->	

    