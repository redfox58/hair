
{
  "title": "COTO MAKASSAR Makassar Beef Soup ",
  "image": "https://img-global.cpcdn.com/recipes/0380d8c2907be405/680x482cq70/coto-makassar-makassar-beef-soup-recipe-main-photo.jpg",
  "LanguageCode": "",
  "future": True
  "PublishDate: "2021-04-23T07:54:21.495Z",
  "thumbnail": "https://img-global.cpcdn.com/recipes/0380d8c2907be405/680x482cq70/coto-makassar-makassar-beef-soup-recipe-main-photo.jpg",
  "cover": "https://img-global.cpcdn.com/recipes/0380d8c2907be405/680x482cq70/coto-makassar-makassar-beef-soup-recipe-main-photo.jpg",
  "categories": "Uncategorized",
  "recipecategory": "Uncategorized"
  "keywords": "Uncategorized",
  "nutrition": "257 calories",
  "tag": ["indonesia", "launch"],
  "recipeyield": "1"
  "description": "cara mudah membuat COTO MAKASSAR (Makassar Beef Soup)"
  "author": "Charlotte Phelps",
  "preptime": "PT22M",
  "cooktime": "PT2H",
  "calories": "291 calories",
  "fatContent": "11 grams fat",
  "ratingValue": "3.5",
  "reviewCount": "7", 
  "recipeIngredient": [
		"200 gram beef", 
		"200 gram tripe boiled", 
		"100 gram beef heart boiled well", 
		"1  4 litters of rice washing water", 
		"4 lemon grass bruised", 
		"3 salam leave bay leaves", 
		"150 gram groundnut fried and mashed", 
		"3 tablespoon cooking oil for sauting", 
		"4 cm ginnger", 
		"1 tablespoon beef broth powder", 
		"4 tablespoons vegetables oil", 
		" Ground Spices", 
		"7 pieces candlenuts roasted", 
		"5 cloves garlic", 
		"3 shallots", 
		"1 tablespoon coriander roasted", 
		"1 teaspoon cumin roasted", 
		"1 teaspoon pepper", 
		"to taste Salt and sugar", 
		" For The Steamed rice with herbal Buras Burasa", 
		"500 gram rice washed and drained", 
		"1 litter coconut milk", 
		"2 teaspoon salt", 
		"2 Salam leaves bay leaves", 
		" Banana leaves for wrapping", 
		" String for tying", 
		" For the Sambal Goreng ", 
		"500 gram peeled potatoes peeled cut into cubes and washed", 
		" Cooking oil heated", 
		"250 gram beef liver washed", 
		"2 tablespoons ground red chilies", 
		"3 bay leaves", 
		"100 gram stink bean optional", 
		"100 ml coconut milk", 
		" Ground Spices", 
		"5 of candlenuts", 
		"3 shallots", 
		"4 cloves garlic", 
		"6 red chillies", 
		"5-7 birds eye chilli optional"
		],
  "recipeInstructions": [ 
        "For the Coto Makasar Heat the oil in a skillet saute the spice paste until fragrant then add to the broth add the powdered broth refined beans bring to a boilThen add beef stew tripe liver and heart of beef with rice washing water add lemongrass galangal ginger and bay leaves until tender", 
        "For the Buras Burasa steamed rice with herb  Boil rice coconut milk salt and salam leaves until the rice is half cooked and tender Fill banana leaf with 23 tablespoon rice roll up and fold both ends Take 2 buras arrange them with fold facing each other on the inside and tie with string in 34 place Steam boiled for about 12 hour until cooked", 
        "For the Sambal Goreng  Fried potatoes with oil until it changes colour and a lot of tender DrainBoiled beef liver to the outside and it solidifies and not chewy remove and drain Sized diced potatoes Set asideSaute the minced chilli spices together until fragrant and not runny add the bay leafAdd salt and sugar to taste Put the potatoes beef liver and the stink bean Add the coconut milk and stir well until combine"]
}






![COTO MAKASSAR (Makassar Beef Soup)](https://img-global.cpcdn.com/recipes/0380d8c2907be405/680x482cq70/coto-makassar-makassar-beef-soup-recipe-main-photo.jpg)
Ibu sedang mencari ide resep coto makassar (makassar beef soup) yang unik? 

Berikut ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah coto makassar (makassar beef soup) yang siap dikreasikan. Nah, kali ini kita coba, yuk, variasikan coto makassar (makassar beef soup) sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh  kita. Anda dapat menyiapkan COTO MAKASSAR (Makassar Beef Soup) menggunakan 40 bahan dan 3 langkah pembuatan. Berikut ini cara untuk membuat hidangannya.
<!--inarticleads1-->
#### Beberapa Bahan Yang digunakan untuk menyiapkan COTO MAKASSAR (Makassar Beef Soup):

- Persiapkan **200 gram** beef. 
- Siapkan **200 gram** tripe, boiled. 
- Siapkan **100 gram** beef heart, boiled well. 
- Persiapkan **1** . 4 litters of rice washing water. 
- Sediakan **4** lemon grass bruised. 
- Siapkan **3** salam leave (bay leaves). 
- Siapkan **150 gram** groundnut (fried and mashed). 
- Sediakan **3 tablespoon** cooking oil for sauting. 
- Persiapkan **4 cm** ginnger. 
- Sediakan **1 tablespoon** beef broth powder. 
- Siapkan **4 tablespoons** vegetables oil. 
- Sediakan **** Ground Spices:. 
- Persiapkan **7 pieces** candlenuts roasted. 
- Siapkan **5 cloves** garlic. 
- Sediakan **3** shallots. 
- Siapkan **1 tablespoon** coriander roasted. 
- Persiapkan **1 teaspoon** cumin roasted. 
- Persiapkan **1 teaspoon** pepper. 
- Siapkan **to taste** Salt and sugar. 
- Persiapkan **** For The Steamed rice with herbal (Buras/ Burasa). 
- Sediakan **500 gram** rice washed and drained. 
- Persiapkan **1** litter coconut milk. 
- Sediakan **2 teaspoon** salt. 
- Sediakan **2** Salam leaves (bay leaves). 
- Persiapkan **** Banana leaves, for wrapping. 
- Persiapkan **** String, for tying. 
- Sediakan **** For the Sambal Goreng :. 
- Sediakan **500 gram** peeled potatoes, peeled, cut into cubes and washed. 
- Sediakan **** Cooking oil, heated. 
- Siapkan **250 gram** beef liver, washed. 
- Persiapkan **2 tablespoons** ground red chilies. 
- Sediakan **3** bay leaves. 
- Persiapkan **100 gram** stink bean (optional). 
- Siapkan **100 ml** coconut milk. 
- Sediakan **** Ground Spices:. 
- Sediakan **5** of candlenuts. 
- Sediakan **3** shallots. 
- Persiapkan **4 cloves** garlic. 
- Persiapkan **6** red chillies. 
- Persiapkan **5-7** bird&#39;s eye chilli (optional). 
<!--inarticleads2-->	
#### Cara Mengolah COTO MAKASSAR (Makassar Beef Soup):
		
1. For the Coto Makasar: Heat the oil in a skillet, saute the spice paste until fragrant, then add to the broth, add the powdered broth, refined beans, bring to a boil.
Then add beef stew, tripe, liver and heart of beef with rice washing water, add lemongrass, galangal, ginger and bay leaves until tender.		
1. For the Buras/ Burasa (steamed rice with herb) : Boil rice, coconut milk, salt and salam leaves until the rice is half cooked and tender. Fill banana leaf with 2-3 tablespoon rice, roll up and fold both ends. Take 2 buras, arrange them with fold facing each other on the inside and tie with string in 3-4 place. Steam/ boiled for about 1-2 hour until cooked.		
1. For the Sambal Goreng : Fried potatoes with oil until it changes colour and a lot of tender. Drain.
Boiled beef liver to the outside and it solidifies and not chewy, remove and drain. Sized diced potatoes. Set aside.
Saute the minced chilli spices together until fragrant and not runny, add the bay leaf.
Add salt and sugar, to taste. Put the potatoes, beef liver, and the stink bean. Add the coconut milk and stir well until combine.
<!--inarticleads3-->	

    