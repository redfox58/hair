[![Netlify Status](https://api.netlify.com/api/v1/badges/98466ce3-0685-49b9-bedc-23d5acf4ce7f/deploy-status)](https://app.netlify.com/sites/recipesbook/deploys)

### local server

`hugo server -D`
